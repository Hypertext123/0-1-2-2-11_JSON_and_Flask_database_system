from flask import Flask, request, render_template
import json
import re

regex = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,7}\b'

app = Flask(__name__)  


@app.route('/login', methods =["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")

        import json
        
        with open("data.json", 'r') as file1:
            file1_data = json.load(file1)

        for i in file1_data["data1"]:
            if i["username"] == username:
                ii = i['password']
                if password == ii:
                    return render_template ("homepage.html")
                else:
                    return render_template ("loginFailed.html")

    return render_template("login.html")


@app.route('/signup', methods =["GET", "POST"])
def signup():
    if request.method == "POST":
        email = request.form.get("email")
        username = request.form.get("username")
        password = request.form.get("password")
        conf_password = request.form.get("conf_password")

        if(re.fullmatch(regex, email)):
            import json
        
            with open("data.json", 'r') as file1:
                file1_data = json.load(file1)

            for i in file1_data["data1"]:
                if i["email"] == email:
                    return render_template("signupEmailAlreadyInUse.html")
                else:
                    if i["username"] == username:
                        return render_template("signupUsernameAlreadyInUse.html")
                    else:
                        if conf_password == password:
                            import json

                            def write_json(new_data, filename="data.json"):
                                with open(filename, 'r+') as file:
                                    file_data = json.load(file)
                                    file_data["data1"].append(new_data)
                                    file.seek(0)
                                    json.dump(file_data, file, indent = 4)

                            user_data = {
                                "email" : email,
                                "username" : username,
                                "password" : password,
                            }

                            write_json(user_data)

                            return render_template("signupSuccess.html")
                        else:
                            return render_template("signupPasswordsDontMatch.html")

        else:
            return render_template("signupInvalidEmail.html")


    return render_template("signup.html")


@app.route('/1', methods =["GET", "POST"])
def homepage1():
    return render_template("index1.html")


@app.route('/', methods =["GET", "POST"])
def gfg():
    return render_template("index.html")


if __name__=='__main__':
   app.run()